import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Battery, 
  Truck, 
  Clock, 
  Zap, 
  TrendingUp, 
  AlertTriangle,
  MapPin,
  Users,
  Calendar,
  MoreVertical
} from "lucide-react";

export function Dashboard() {
  const stations = [
    { id: "ST001", name: "Mumbai Central", status: "charging", vehicle: "MH-01-EV-1234", progress: 75, eta: "25 min" },
    { id: "ST002", name: "Delhi Hub", status: "available", vehicle: null, progress: 0, eta: null },
    { id: "ST003", name: "Bangalore South", status: "charging", vehicle: "KA-05-EV-5678", progress: 45, eta: "1h 15min" },
    { id: "ST004", name: "Chennai Port", status: "booked", vehicle: "TN-09-EV-9012", progress: 0, eta: "2h 30min" },
    { id: "ST005", name: "Hyderabad East", status: "available", vehicle: null, progress: 0, eta: null },
    { id: "ST006", name: "Pune West", status: "charging", vehicle: "MH-12-EV-3456", progress: 90, eta: "8 min" }
  ];

  const recentBookings = [
    { id: "BK001", company: "VRL Logistics", vehicle: "MH-01-EV-1234", driver: "Rajesh Kumar", route: "Mumbai → Pune", time: "2:00 PM - 4:00 PM", status: "active" },
    { id: "BK002", company: "Delhivery", vehicle: "DL-02-EV-5678", driver: "Priya Sharma", route: "Delhi → Gurgaon", time: "3:30 PM - 5:30 PM", status: "upcoming" },
    { id: "BK003", company: "Amazon", vehicle: "KA-05-EV-9012", driver: "Suresh Reddy", route: "Bangalore → Mysore", time: "4:00 PM - 6:00 PM", status: "upcoming" }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "charging":
        return <Badge variant="charging">Charging</Badge>;
      case "available":
        return <Badge variant="success">Available</Badge>;
      case "booked":
        return <Badge variant="warning">Booked</Badge>;
      default:
        return <Badge variant="available">Unknown</Badge>;
    }
  };

  const getBookingStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="charging">Active</Badge>;
      case "upcoming":
        return <Badge variant="warning">Upcoming</Badge>;
      default:
        return <Badge variant="available">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted/30 pt-20 pb-10">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">Fleet Charging Dashboard</h1>
          <p className="text-lg text-muted-foreground">Real-time overview of your EV charging operations</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-card shadow-elegant hover:shadow-primary transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Stations</p>
                  <p className="text-3xl font-bold text-primary">4/6</p>
                  <p className="text-sm text-success"><TrendingUp className="w-4 h-4 inline mr-1" />67% Utilization</p>
                </div>
                <div className="bg-primary/10 p-3 rounded-full">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card shadow-elegant hover:shadow-secondary transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Fleet Vehicles</p>
                  <p className="text-3xl font-bold text-secondary">24</p>
                  <p className="text-sm text-success"><Battery className="w-4 h-4 inline mr-1" />18 Charging</p>
                </div>
                <div className="bg-secondary/10 p-3 rounded-full">
                  <Truck className="w-6 h-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card shadow-elegant hover:shadow-primary transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Today's Bookings</p>
                  <p className="text-3xl font-bold text-accent">32</p>
                  <p className="text-sm text-success"><Calendar className="w-4 h-4 inline mr-1" />8 Pending</p>
                </div>
                <div className="bg-accent/10 p-3 rounded-full">
                  <Clock className="w-6 h-6 text-accent" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-card shadow-elegant hover:shadow-warning transition-all duration-300">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Alerts</p>
                  <p className="text-3xl font-bold text-warning">2</p>
                  <p className="text-sm text-warning"><AlertTriangle className="w-4 h-4 inline mr-1" />Delayed</p>
                </div>
                <div className="bg-warning/10 p-3 rounded-full">
                  <AlertTriangle className="w-6 h-6 text-warning" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Live Station Status */}
          <div className="lg:col-span-2">
            <Card className="shadow-elegant">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="w-5 h-5 mr-2 text-primary" />
                  Live Station Status
                </CardTitle>
                <CardDescription>Real-time monitoring of all charging stations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stations.map((station) => (
                    <div key={station.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <MapPin className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{station.name}</h4>
                          <p className="text-sm text-muted-foreground">{station.id}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        {station.vehicle && (
                          <div className="text-right">
                            <p className="text-sm font-medium text-foreground">{station.vehicle}</p>
                            {station.progress > 0 && (
                              <div className="flex items-center space-x-2">
                                <div className="w-20 bg-muted rounded-full h-2">
                                  <div 
                                    className="bg-primary rounded-full h-2 transition-all duration-300"
                                    style={{ width: `${station.progress}%` }}
                                  />
                                </div>
                                <span className="text-xs text-muted-foreground">{station.progress}%</span>
                              </div>
                            )}
                          </div>
                        )}
                        
                        <div className="text-right">
                          {getStatusBadge(station.status)}
                          {station.eta && (
                            <p className="text-xs text-muted-foreground mt-1">{station.eta} remaining</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Bookings */}
          <div>
            <Card className="shadow-elegant">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-secondary" />
                  Recent Bookings
                </CardTitle>
                <CardDescription>Latest fleet charging schedules</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentBookings.map((booking) => (
                    <div key={booking.id} className="p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-foreground text-sm">{booking.company}</h4>
                        {getBookingStatusBadge(booking.status)}
                      </div>
                      <div className="space-y-1 text-sm text-muted-foreground">
                        <p><Truck className="w-3 h-3 inline mr-1" />{booking.vehicle}</p>
                        <p><Users className="w-3 h-3 inline mr-1" />{booking.driver}</p>
                        <p><MapPin className="w-3 h-3 inline mr-1" />{booking.route}</p>
                        <p><Clock className="w-3 h-3 inline mr-1" />{booking.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-4" variant="outline">
                  View All Bookings
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}