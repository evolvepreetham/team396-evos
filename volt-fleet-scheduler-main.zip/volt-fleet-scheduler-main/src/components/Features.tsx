import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Users, 
  Calendar, 
  BarChart3, 
  MapPin, 
  Settings, 
  Smartphone,
  Shield,
  Clock,
  Truck,
  Battery,
  Zap,
  TrendingUp
} from "lucide-react";

export function Features() {
  const features = [
    {
      icon: Users,
      title: "Company Portal",
      description: "Dedicated dashboards for logistics companies like VRL, Delhivery, and Amazon",
      features: ["Multi-company management", "Role-based access", "Fleet registration", "Driver assignment"],
      badge: "Enterprise Ready"
    },
    {
      icon: Calendar,
      title: "Smart Scheduler",
      description: "AI-powered charging schedule optimization with conflict detection",
      features: ["Interactive calendar view", "Automatic conflict resolution", "Route integration", "Time slot booking"],
      badge: "AI Powered"
    },
    {
      icon: BarChart3,
      title: "Live Dashboard",
      description: "Real-time monitoring and analytics for operational insights",
      features: ["Station utilization charts", "Fleet performance metrics", "Predictive analytics", "Custom reports"],
      badge: "Real-time"
    },
    {
      icon: MapPin,
      title: "Route Integration",
      description: "Seamlessly connect charging stops with delivery routes",
      features: ["GPS tracking", "ETA predictions", "Route optimization", "Delay notifications"],
      badge: "Location Based"
    },
    {
      icon: Smartphone,
      title: "Driver Notifications",
      description: "Keep drivers informed with SMS and email alerts",
      features: ["Booking confirmations", "Charging reminders", "Route updates", "Emergency alerts"],
      badge: "Connected"
    },
    {
      icon: Settings,
      title: "Admin Controls",
      description: "Complete system management and configuration tools",
      features: ["Station management", "User permissions", "Data export", "System monitoring"],
      badge: "Full Control"
    }
  ];

  const benefits = [
    {
      icon: Clock,
      title: "Save Time",
      description: "Reduce scheduling conflicts by 85% with intelligent automation",
      metric: "85%"
    },
    {
      icon: Battery,
      title: "Optimize Usage",
      description: "Increase charging station utilization and reduce downtime",
      metric: "94%"
    },
    {
      icon: TrendingUp,
      title: "Boost Efficiency",
      description: "Improve fleet operational efficiency with data-driven insights",
      metric: "+40%"
    },
    {
      icon: Shield,
      title: "Ensure Reliability",
      description: "99.9% uptime guarantee with enterprise-grade infrastructure",
      metric: "99.9%"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-muted/20 to-background py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge variant="secondary" className="mb-4">
            <Zap className="w-4 h-4 mr-2" />
            Comprehensive Features
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Everything Your Fleet Needs
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From smart scheduling to real-time monitoring, our platform provides all the tools 
            logistics companies need to manage their EV charging operations efficiently.
          </p>
        </div>

        {/* Main Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="shadow-elegant hover:shadow-primary transition-all duration-300 hover:scale-105 bg-gradient-card"
            >
              <CardHeader>
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-gradient-primary w-12 h-12 rounded-full flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {feature.badge}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
                <CardDescription className="text-base">{feature.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {feature.features.map((item, idx) => (
                    <li key={idx} className="flex items-center text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mr-3" />
                      {item}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Benefits Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Proven Results for Leading Companies
            </h3>
            <p className="text-lg text-muted-foreground">
              Join industry leaders who trust our platform for their EV fleet management
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => (
              <Card key={benefit.title} className="text-center shadow-elegant bg-gradient-card">
                <CardContent className="p-6">
                  <div className="bg-gradient-primary w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <benefit.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{benefit.metric}</div>
                  <h4 className="font-semibold text-foreground mb-2">{benefit.title}</h4>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-primary text-white shadow-primary">
          <CardContent className="p-12 text-center">
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Ready to Transform Your Fleet Operations?
            </h3>
            <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Join thousands of logistics companies already using ChargeMaster to optimize their EV charging operations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="xl" variant="secondary" className="text-lg font-semibold">
                <Truck className="w-5 h-5 mr-2" />
                Start Free Trial
              </Button>
              <Button size="xl" variant="outline" className="border-white/30 text-white hover:bg-white/20">
                Schedule Demo
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}