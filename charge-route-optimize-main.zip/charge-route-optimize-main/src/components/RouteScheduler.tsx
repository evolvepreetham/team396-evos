import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Plus, Route } from "lucide-react";

export const RouteScheduler = () => {
  const scheduledRoutes = [
    {
      id: "RT-001",
      route: "Mumbai → Bangalore",
      vehicle: "EV-012",
      driver: "Suresh Reddy",
      startTime: "06:00 AM",
      chargingStops: [
        { station: "Pune Fast Charge", time: "09:30 AM", duration: "45min" },
        { station: "Kolhapur Hub", time: "01:15 PM", duration: "30min" },
        { station: "Belgaum Station", time: "04:45 PM", duration: "40min" }
      ],
      status: "scheduled"
    },
    {
      id: "RT-002", 
      route: "Delhi → Jaipur",
      vehicle: "EV-008",
      driver: "Kavita Gupta",
      startTime: "05:30 AM",
      chargingStops: [
        { station: "Gurgaon Express", time: "07:00 AM", duration: "25min" },
        { station: "Alwar Central", time: "10:30 AM", duration: "35min" }
      ],
      status: "active"
    }
  ];

  const getStatusBadge = (status: string) => {
    if (status === "active") {
      return <Badge variant="default" className="bg-success/10 text-success border-success/20">Active</Badge>;
    }
    if (status === "scheduled") {
      return <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">Scheduled</Badge>;
    }
    return <Badge variant="outline">Completed</Badge>;
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Route className="h-5 w-5" />
            <span>Route Scheduler</span>
          </CardTitle>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Route
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {scheduledRoutes.map((route) => (
            <div key={route.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="font-semibold text-lg">{route.route}</div>
                  <div className="text-sm text-muted-foreground">
                    {route.vehicle} • {route.driver}
                  </div>
                </div>
                {getStatusBadge(route.status)}
              </div>

              <div className="flex items-center space-x-4 mb-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Start: {route.startTime}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{route.chargingStops.length} charging stops</span>
                </div>
              </div>

              <div className="space-y-2">
                <div className="text-sm font-medium text-muted-foreground">Charging Schedule:</div>
                {route.chargingStops.map((stop, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-muted/30 rounded">
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-primary rounded-full" />
                      <span className="text-sm font-medium">{stop.station}</span>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stop.time} • {stop.duration}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex space-x-2 mt-4">
                <Button variant="outline" size="sm">View Details</Button>
                <Button variant="outline" size="sm">Reschedule</Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};