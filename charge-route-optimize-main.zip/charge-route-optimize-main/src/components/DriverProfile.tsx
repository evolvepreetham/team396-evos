import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  User, 
  MapPin, 
  Clock, 
  Battery, 
  Navigation, 
  Zap,
  Route,
  Phone,
  Mail,
  Car
} from "lucide-react";

export const DriverProfile = () => {
  const driverData = {
    id: "DRV-001",
    name: "Rajesh Kumar",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    phone: "+91 98765 43210",
    email: "rajesh.kumar@company.com",
    vehicleId: "EV-001",
    license: "KA05-2023-001234",
    currentRoute: {
      from: "Bangalore",
      to: "Chennai", 
      distance: "347 km",
      estimatedTime: "6h 30m",
      startTime: "06:00 AM",
      currentLocation: "Electronic City",
      progress: 15
    },
    chargingStops: [
      {
        id: 1,
        name: "Hosur Charging Hub",
        location: "Hosur, Tamil Nadu",
        distance: "42 km from start",
        estimatedArrival: "07:15 AM",
        chargingDuration: "45 min",
        status: "upcoming",
        batteryBefore: 65,
        batteryAfter: 90
      },
      {
        id: 2,
        name: "Krishnagiri Fast Charge",
        location: "Krishnagiri, Tamil Nadu", 
        distance: "128 km from start",
        estimatedArrival: "10:30 AM",
        chargingDuration: "30 min",
        status: "scheduled",
        batteryBefore: 45,
        batteryAfter: 80
      },
      {
        id: 3,
        name: "Vellore Express Station",
        location: "Vellore, Tamil Nadu",
        distance: "245 km from start", 
        estimatedArrival: "02:15 PM",
        chargingDuration: "40 min",
        status: "scheduled",
        batteryBefore: 25,
        batteryAfter: 75
      }
    ],
    currentBattery: 85,
    nextChargingStop: "Hosur Charging Hub"
  };

  const getStatusBadge = (status: string) => {
    if (status === "upcoming") {
      return <Badge variant="default" className="bg-info/10 text-info border-info/20">Next Stop</Badge>;
    }
    if (status === "scheduled") {
      return <Badge variant="outline">Scheduled</Badge>;
    }
    return <Badge variant="secondary">Completed</Badge>;
  };

  const getBatteryColor = (battery: number) => {
    if (battery >= 70) return "text-success";
    if (battery >= 30) return "text-warning";
    return "text-destructive";
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <User className="h-5 w-5" />
          <span>Driver Profile</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Driver Info */}
        <div className="flex items-center space-x-4 p-4 bg-gradient-surface rounded-lg">
          <Avatar className="h-16 w-16">
            <AvatarImage src={driverData.avatar} alt={driverData.name} />
            <AvatarFallback className="bg-primary text-primary-foreground">
              {driverData.name.split(' ').map(n => n[0]).join('')}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="text-lg font-semibold">{driverData.name}</h3>
            <p className="text-sm text-muted-foreground">{driverData.id}</p>
            <div className="flex items-center space-x-4 mt-2 text-sm">
              <div className="flex items-center space-x-1">
                <Phone className="h-3 w-3" />
                <span>{driverData.phone}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Car className="h-3 w-3" />
                <span>{driverData.vehicleId}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Current Route */}
        <div className="space-y-4">
          <h4 className="font-semibold flex items-center space-x-2">
            <Route className="h-4 w-4" />
            <span>Current Route</span>
          </h4>
          
          <div className="p-4 border rounded-lg bg-card">
            <div className="flex items-center justify-between mb-4">
              <div className="text-lg font-medium">
                {driverData.currentRoute.from} → {driverData.currentRoute.to}
              </div>
              <Badge variant="default" className="bg-success/10 text-success border-success/20">
                Active
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Distance</div>
                <div className="font-medium">{driverData.currentRoute.distance}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Est. Time</div>
                <div className="font-medium">{driverData.currentRoute.estimatedTime}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Start Time</div>
                <div className="font-medium">{driverData.currentRoute.startTime}</div>
              </div>
              <div className="space-y-1">
                <div className="text-sm text-muted-foreground">Current Location</div>
                <div className="font-medium">{driverData.currentRoute.currentLocation}</div>
              </div>
            </div>

            {/* Current Battery Status */}
            <div className="p-3 bg-muted/30 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <Battery className={`h-4 w-4 ${getBatteryColor(driverData.currentBattery)}`} />
                  <span className="text-sm font-medium">Current Battery</span>
                </div>
                <span className={`font-bold ${getBatteryColor(driverData.currentBattery)}`}>
                  {driverData.currentBattery}%
                </span>
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${
                    driverData.currentBattery >= 70 ? 'bg-success' :
                    driverData.currentBattery >= 30 ? 'bg-warning' : 'bg-destructive'
                  }`}
                  style={{ width: `${driverData.currentBattery}%` }}
                />
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Next charging stop: {driverData.nextChargingStop}
              </div>
            </div>
          </div>
        </div>

        {/* Charging Schedule */}
        <div className="space-y-4">
          <h4 className="font-semibold flex items-center space-x-2">
            <Zap className="h-4 w-4" />
            <span>Charging Schedule</span>
          </h4>
          
          <div className="space-y-3">
            {driverData.chargingStops.map((stop) => (
              <div key={stop.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium">{stop.name}</div>
                  {getStatusBadge(stop.status)}
                </div>
                
                <div className="text-sm text-muted-foreground mb-3">{stop.location}</div>
                
                <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span>{stop.distance}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-3 w-3 text-muted-foreground" />
                    <span>ETA: {stop.estimatedArrival}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Zap className="h-3 w-3 text-muted-foreground" />
                    <span>Duration: {stop.chargingDuration}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Battery className="h-3 w-3 text-muted-foreground" />
                    <span>{stop.batteryBefore}% → {stop.batteryAfter}%</span>
                  </div>
                </div>

                {stop.status === "upcoming" && (
                  <Button variant="outline" size="sm" className="w-full">
                    <Navigation className="h-4 w-4 mr-2" />
                    Navigate to Station
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};