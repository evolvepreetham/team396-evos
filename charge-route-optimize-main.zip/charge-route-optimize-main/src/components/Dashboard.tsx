import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Truck, 
  Battery, 
  MapPin, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  Upload,
  BarChart3,
  Calendar,
  Users
} from "lucide-react";
import { FleetOverview } from "./FleetOverview";
import { RouteScheduler } from "./RouteScheduler";
import { DriverProfile } from "./DriverProfile";
import { AdminProfile } from "./AdminProfile";

export const Dashboard = () => {
  const stats = [
    {
      title: "Active Vehicles",
      value: "24",
      icon: Truck,
      trend: "+2 from yesterday",
      variant: "primary" as const
    },
    {
      title: "Charging Sessions",
      value: "18",
      icon: Battery,
      trend: "6 in progress",
      variant: "accent" as const
    },
    {
      title: "Route Optimization",
      value: "94%",
      icon: MapPin,
      trend: "+5% efficiency",
      variant: "success" as const
    },
    {
      title: "Avg. Charging Time",
      value: "45min",
      icon: Clock,
      trend: "-8min vs last week",
      variant: "info" as const
    }
  ];

  const alerts = [
    { type: "warning", message: "Vehicle EV-024 battery below 20%", time: "2 min ago" },
    { type: "error", message: "Charging station CS-12 offline", time: "15 min ago" },
    { type: "success", message: "Route BLR-CHN optimized successfully", time: "1 hour ago" }
  ];

  return (
    <div className="min-h-screen bg-gradient-surface">
      {/* Header */}
      <header className="border-b bg-card shadow-soft">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                  <Truck className="h-5 w-5 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">FleetCharge Pro</h1>
                  <p className="text-sm text-muted-foreground">EV Fleet Management</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm">
                <Upload className="h-4 w-4 mr-2" />
                Upload Schedule
              </Button>
              <Button variant="default" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                Plan Routes
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="shadow-soft hover:shadow-medium transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{stat.trend}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    stat.variant === 'primary' ? 'bg-primary/10' :
                    stat.variant === 'accent' ? 'bg-accent/10' :
                    stat.variant === 'success' ? 'bg-success/10' :
                    'bg-info/10'
                  }`}>
                    <stat.icon className={`h-6 w-6 ${
                      stat.variant === 'primary' ? 'text-primary' :
                      stat.variant === 'accent' ? 'text-accent' :
                      stat.variant === 'success' ? 'text-success' :
                      'text-info'
                    }`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Fleet Overview */}
          <div className="lg:col-span-2">
            <FleetOverview />
          </div>

          {/* Alerts Panel */}
          <div>
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5" />
                  <span>System Alerts</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {alerts.map((alert, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-muted/50">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      alert.type === 'error' ? 'bg-destructive' :
                      alert.type === 'warning' ? 'bg-warning' :
                      'bg-success'
                    }`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{alert.message}</p>
                      <p className="text-xs text-muted-foreground">{alert.time}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Bottom Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <RouteScheduler />
          <DriverProfile />
        </div>

        {/* Admin Profile Section */}
        <div className="mt-6">
          <AdminProfile />
        </div>
      </div>
    </div>
  );
};