import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Users, 
  MapPin, 
  Clock, 
  Battery, 
  Route,
  Car,
  Calendar,
  Settings,
  Eye,
  Edit,
  MoreHorizontal,
  Phone
} from "lucide-react";

export const AdminProfile = () => {
  const allDrivers = [
    {
      id: "DRV-001",
      name: "Rajesh Kumar",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      vehicle: "EV-001",
      route: "BLR → CHN",
      status: "active",
      battery: 85,
      location: "Electronic City",
      nextStop: "Hosur Charging Hub",
      eta: "7:15 AM"
    },
    {
      id: "DRV-002", 
      name: "Priya Sharma",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b03c?w=150&h=150&fit=crop&crop=face",
      vehicle: "EV-007",
      route: "MUM → PUN",
      status: "charging",
      battery: 45,
      location: "Lonavala Charge Station",
      nextStop: "Pune Central",
      eta: "1:45 PM"
    },
    {
      id: "DRV-003",
      name: "Amit Patel", 
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      vehicle: "EV-015",
      route: "DEL → AGR",
      status: "low_battery",
      battery: 23,
      location: "Mathura",
      nextStop: "Mathura Fast Charge",
      eta: "30 min"
    },
    {
      id: "DRV-004",
      name: "Deepika Singh",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face", 
      vehicle: "EV-022",
      route: "HYD → VJA",
      status: "scheduled",
      battery: 95,
      location: "Hyderabad Depot",
      nextStop: "Nalgonda Station",
      eta: "8:00 AM"
    }
  ];

  const allRoutes = [
    {
      id: "RT-001",
      route: "Mumbai → Bangalore",
      driver: "Suresh Reddy",
      vehicle: "EV-012",
      status: "active",
      progress: 45,
      totalDistance: "985 km",
      chargingStops: 4,
      startTime: "06:00 AM",
      expectedCompletion: "11:30 PM"
    },
    {
      id: "RT-002",
      route: "Delhi → Jaipur", 
      driver: "Kavita Gupta",
      vehicle: "EV-008",
      status: "completed",
      progress: 100,
      totalDistance: "280 km",
      chargingStops: 2,
      startTime: "05:30 AM",
      expectedCompletion: "11:00 AM"
    },
    {
      id: "RT-003",
      route: "Chennai → Coimbatore",
      driver: "Ravi Krishnan", 
      vehicle: "EV-019",
      status: "scheduled",
      progress: 0,
      totalDistance: "507 km",
      chargingStops: 3,
      startTime: "07:00 AM",
      expectedCompletion: "02:30 PM"
    },
    {
      id: "RT-004",
      route: "Kolkata → Bhubaneswar",
      driver: "Anita Das",
      vehicle: "EV-025", 
      status: "delayed",
      progress: 25,
      totalDistance: "440 km",
      chargingStops: 3,
      startTime: "06:30 AM",
      expectedCompletion: "03:00 PM"
    }
  ];

  const todaySchedule = [
    { time: "05:30 AM", event: "EV-008 departure", route: "DEL → JPR", driver: "Kavita Gupta" },
    { time: "06:00 AM", event: "EV-012 departure", route: "MUM → BLR", driver: "Suresh Reddy" },
    { time: "07:00 AM", event: "EV-019 departure", route: "CHN → CBE", driver: "Ravi Krishnan" },
    { time: "07:15 AM", event: "EV-001 charging", route: "BLR → CHN", driver: "Rajesh Kumar" },
    { time: "08:00 AM", event: "EV-022 departure", route: "HYD → VJA", driver: "Deepika Singh" },
    { time: "10:30 AM", event: "EV-008 charging", route: "DEL → JPR", driver: "Kavita Gupta" }
  ];

  const getDriverStatusBadge = (status: string) => {
    if (status === "active") {
      return <Badge variant="default" className="bg-success/10 text-success border-success/20">Active</Badge>;
    }
    if (status === "charging") {
      return <Badge variant="secondary" className="bg-info/10 text-info border-info/20">Charging</Badge>;
    }
    if (status === "low_battery") {
      return <Badge variant="destructive">Low Battery</Badge>;
    }
    if (status === "scheduled") {
      return <Badge variant="outline">Scheduled</Badge>;
    }
    return <Badge variant="secondary">Idle</Badge>;
  };

  const getRouteStatusBadge = (status: string) => {
    if (status === "active") {
      return <Badge variant="default" className="bg-success/10 text-success border-success/20">Active</Badge>;
    }
    if (status === "completed") {
      return <Badge variant="secondary" className="bg-muted text-muted-foreground">Completed</Badge>;
    }
    if (status === "scheduled") {
      return <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">Scheduled</Badge>;
    }
    if (status === "delayed") {
      return <Badge variant="destructive">Delayed</Badge>;
    }
    return <Badge variant="outline">Unknown</Badge>;
  };

  const getBatteryColor = (battery: number) => {
    if (battery >= 70) return "text-success";
    if (battery >= 30) return "text-warning";
    return "text-destructive";
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-soft">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>Admin Dashboard</span>
            </CardTitle>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Calendar className="h-4 w-4 mr-2" />
                View Calendar
              </Button>
              <Button variant="default" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Fleet Settings
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* All Drivers Overview */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center space-x-2">
                <Users className="h-4 w-4" />
                <span>All Drivers ({allDrivers.length})</span>
              </h4>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {allDrivers.map((driver) => (
                  <div key={driver.id} className="p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={driver.avatar} alt={driver.name} />
                          <AvatarFallback className="text-xs">
                            {driver.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="text-sm font-medium">{driver.name}</div>
                          <div className="text-xs text-muted-foreground">{driver.id}</div>
                        </div>
                      </div>
                      {getDriverStatusBadge(driver.status)}
                    </div>
                    
                    <div className="space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Vehicle:</span>
                        <span className="font-medium">{driver.vehicle}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Route:</span>
                        <span className="font-medium">{driver.route}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Battery:</span>
                        <span className={`font-medium ${getBatteryColor(driver.battery)}`}>
                          {driver.battery}%
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Location:</span>
                        <span className="font-medium">{driver.location}</span>
                      </div>
                    </div>

                    <div className="flex space-x-1 mt-2">
                      <Button variant="outline" size="sm" className="flex-1 text-xs h-7">
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1 text-xs h-7">
                        <Phone className="h-3 w-3 mr-1" />
                        Call
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* All Routes Overview */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center space-x-2">
                <Route className="h-4 w-4" />
                <span>All Routes ({allRoutes.length})</span>
              </h4>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {allRoutes.map((route) => (
                  <div key={route.id} className="p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm font-medium">{route.route}</div>
                      {getRouteStatusBadge(route.status)}
                    </div>
                    
                    <div className="space-y-1 text-xs mb-2">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Driver:</span>
                        <span className="font-medium">{route.driver}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Vehicle:</span>
                        <span className="font-medium">{route.vehicle}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Distance:</span>
                        <span className="font-medium">{route.totalDistance}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Stops:</span>
                        <span className="font-medium">{route.chargingStops} charging</span>
                      </div>
                    </div>

                    {route.status === "active" && (
                      <div className="mb-2">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">{route.progress}%</span>
                        </div>
                        <div className="w-full bg-muted rounded-full h-1.5">
                          <div 
                            className="h-1.5 bg-success rounded-full transition-all duration-300"
                            style={{ width: `${route.progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex space-x-1">
                      <Button variant="outline" size="sm" className="flex-1 text-xs h-7">
                        <Eye className="h-3 w-3 mr-1" />
                        Details
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1 text-xs h-7">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Today's Schedule */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center space-x-2">
                <Calendar className="h-4 w-4" />
                <span>Today's Schedule</span>
              </h4>
              
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {todaySchedule.map((item, index) => (
                  <div key={index} className="p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <div className="text-sm font-medium text-primary">{item.time}</div>
                      <Badge variant="outline" className="text-xs">{item.event.split(' ')[1]}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mb-1">{item.event}</div>
                    <div className="text-xs">
                      <span className="font-medium">{item.route}</span> • {item.driver}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};