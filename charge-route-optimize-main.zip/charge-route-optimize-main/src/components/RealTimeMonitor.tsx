import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Zap, Thermometer, Gauge, AlertTriangle, Wifi } from "lucide-react";

export const RealTimeMonitor = () => {
  const stations = [
    {
      id: "CS-12",
      name: "Pune Fast Charge",
      status: "active",
      occupancy: 3,
      capacity: 4,
      vehicles: [
        { id: "EV-001", voltage: 425, current: 125, temp: 32, progress: 65 },
        { id: "EV-015", voltage: 380, current: 95, temp: 28, progress: 45 },
        { id: "EV-009", voltage: 440, current: 140, temp: 35, progress: 85 }
      ]
    },
    {
      id: "CS-08", 
      name: "Mumbai Central Hub",
      status: "maintenance",
      occupancy: 0,
      capacity: 6,
      vehicles: []
    },
    {
      id: "CS-15",
      name: "Bangalore Express",
      status: "active", 
      occupancy: 2,
      capacity: 3,
      vehicles: [
        { id: "EV-022", voltage: 415, current: 115, temp: 30, progress: 75 },
        { id: "EV-018", voltage: 390, current: 105, temp: 29, progress: 55 }
      ]
    }
  ];

  const getStatusBadge = (status: string) => {
    if (status === "active") {
      return <Badge variant="default" className="bg-success/10 text-success border-success/20">Online</Badge>;
    }
    if (status === "maintenance") {
      return <Badge variant="destructive">Maintenance</Badge>;
    }
    return <Badge variant="secondary">Offline</Badge>;
  };

  const getTemperatureColor = (temp: number) => {
    if (temp > 40) return "text-destructive";
    if (temp > 35) return "text-warning";
    return "text-success";
  };

  const getVoltageStatus = (voltage: number) => {
    if (voltage < 350 || voltage > 450) return "text-warning";
    return "text-success";
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Wifi className="h-5 w-5" />
          <span>Real-Time Monitor</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {stations.map((station) => (
            <div key={station.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="font-semibold">{station.name}</div>
                  <div className="text-sm text-muted-foreground">{station.id}</div>
                </div>
                <div className="flex items-center space-x-2">
                  {getStatusBadge(station.status)}
                  <Badge variant="outline">
                    {station.occupancy}/{station.capacity}
                  </Badge>
                </div>
              </div>

              {station.status === "active" && station.vehicles.length > 0 && (
                <div className="space-y-3">
                  <div className="text-sm font-medium text-muted-foreground">Active Sessions:</div>
                  {station.vehicles.map((vehicle) => (
                    <div key={vehicle.id} className="p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="font-medium">{vehicle.id}</div>
                        <div className="text-sm text-muted-foreground">
                          {vehicle.progress}% charged
                        </div>
                      </div>
                      
                      <Progress value={vehicle.progress} className="mb-3 h-2" />
                      
                      <div className="grid grid-cols-3 gap-3 text-sm">
                        <div className="flex items-center space-x-1">
                          <Zap className={`h-3 w-3 ${getVoltageStatus(vehicle.voltage)}`} />
                          <span className="text-muted-foreground">Voltage:</span>
                          <span className={`font-medium ${getVoltageStatus(vehicle.voltage)}`}>
                            {vehicle.voltage}V
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Gauge className="h-3 w-3 text-info" />
                          <span className="text-muted-foreground">Current:</span>
                          <span className="font-medium text-info">{vehicle.current}A</span>
                        </div>
                        
                        <div className="flex items-center space-x-1">
                          <Thermometer className={`h-3 w-3 ${getTemperatureColor(vehicle.temp)}`} />
                          <span className="text-muted-foreground">Temp:</span>
                          <span className={`font-medium ${getTemperatureColor(vehicle.temp)}`}>
                            {vehicle.temp}°C
                          </span>
                        </div>
                      </div>

                      {(vehicle.temp > 35 || vehicle.voltage < 350 || vehicle.voltage > 450) && (
                        <div className="flex items-center space-x-2 mt-2 p-2 bg-warning/10 border border-warning/20 rounded">
                          <AlertTriangle className="h-4 w-4 text-warning" />
                          <span className="text-sm text-warning">
                            {vehicle.temp > 35 ? "High temperature detected" : "Voltage anomaly detected"}
                          </span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {station.status === "maintenance" && (
                <div className="flex items-center space-x-2 p-3 bg-destructive/10 border border-destructive/20 rounded">
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                  <span className="text-sm text-destructive">Station under maintenance</span>
                </div>
              )}

              {station.status === "active" && station.vehicles.length === 0 && (
                <div className="text-center py-4 text-muted-foreground">
                  <Zap className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <div className="text-sm">All charging ports available</div>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};