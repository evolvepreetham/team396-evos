import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Battery, MapPin, Clock, Fuel } from "lucide-react";

export const FleetOverview = () => {
  const vehicles = [
    {
      id: "EV-001",
      driver: "Rajesh Kumar",
      route: "BLR → CHN",
      battery: 85,
      status: "charging",
      location: "Station CS-12",
      eta: "2h 15m",
      nextStop: "Hosur Charging Hub"
    },
    {
      id: "EV-007",
      driver: "Priya Sharma", 
      route: "MUM → PUN",
      battery: 92,
      status: "enroute",
      location: "Lonavala",
      eta: "1h 45m", 
      nextStop: "Pune Central"
    },
    {
      id: "EV-015",
      driver: "Amit Patel",
      route: "DEL → AGR",
      battery: 23,
      status: "low_battery",
      location: "Mathura",
      eta: "30m",
      nextStop: "Mathura Fast Charge"
    },
    {
      id: "EV-022",
      driver: "Deepika Singh",
      route: "HYD → VJA", 
      battery: 67,
      status: "enroute",
      location: "Nalgonda",
      eta: "2h 30m",
      nextStop: "Vijayawada Hub"
    }
  ];

  const getStatusBadge = (status: string, battery: number) => {
    if (status === "charging") {
      return <Badge variant="secondary" className="bg-info/10 text-info border-info/20">Charging</Badge>;
    }
    if (status === "low_battery" || battery < 30) {
      return <Badge variant="destructive">Low Battery</Badge>;
    }
    if (status === "enroute") {
      return <Badge variant="default" className="bg-success/10 text-success border-success/20">En Route</Badge>;
    }
    return <Badge variant="outline">Idle</Badge>;
  };

  const getBatteryColor = (battery: number) => {
    if (battery >= 70) return "text-success";
    if (battery >= 30) return "text-warning"; 
    return "text-destructive";
  };

  return (
    <Card className="shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Fuel className="h-5 w-5" />
          <span>Fleet Overview</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="p-4 border rounded-lg hover:bg-muted/50 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <div className="font-semibold">{vehicle.id}</div>
                  <div className="text-sm text-muted-foreground">{vehicle.driver}</div>
                </div>
                {getStatusBadge(vehicle.status, vehicle.battery)}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">{vehicle.route}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">ETA: {vehicle.eta}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Battery className={`h-4 w-4 ${getBatteryColor(vehicle.battery)}`} />
                      <span className="text-sm">Battery</span>
                    </div>
                    <span className={`text-sm font-medium ${getBatteryColor(vehicle.battery)}`}>
                      {vehicle.battery}%
                    </span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${
                        vehicle.battery >= 70 ? 'bg-success' :
                        vehicle.battery >= 30 ? 'bg-warning' : 'bg-destructive'
                      }`}
                      style={{ width: `${vehicle.battery}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Current: {vehicle.location}</span>
                  <span className="font-medium">Next: {vehicle.nextStop}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};