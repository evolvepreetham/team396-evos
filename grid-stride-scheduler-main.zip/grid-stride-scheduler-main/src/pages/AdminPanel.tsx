import { useState } from 'react';
import { motion } from 'framer-motion';
import { Navbar } from '@/components/layout/Navbar';
import { PageHeader } from '@/components/layout/PageHeader';
import { StatsCard } from '@/components/ui/stats-card';
import { StatusBadge } from '@/components/ui/status-badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { 
  Building, 
  Zap, 
  TrendingUp, 
  Users,
  Plus,
  Settings,
  BarChart3,
  MapPin,
  Calendar
} from 'lucide-react';

// Mock data for admin dashboard
const adminStats = [
  { title: "Total Companies", value: 12, icon: Building, trend: { value: 15, isPositive: true } },
  { title: "Charging Stations", value: 45, icon: Zap, trend: { value: 8, isPositive: true } },
  { title: "Active Vehicles", value: 234, icon: TrendingUp, trend: { value: 12, isPositive: true } },
  { title: "Total Users", value: 89, icon: Users, trend: { value: 5, isPositive: true } },
];

const companyData = [
  {
    id: 1,
    name: 'VRL Logistics',
    vehicles: 24,
    activeRoutes: 12,
    utilizationRate: 85,
    status: 'active'
  },
  {
    id: 2,
    name: 'Delhivery',
    vehicles: 18,
    activeRoutes: 8,
    utilizationRate: 72,
    status: 'active'
  },
  {
    id: 3,
    name: 'Amazon Logistics',
    vehicles: 32,
    activeRoutes: 16,
    utilizationRate: 91,
    status: 'active'
  },
  {
    id: 4,
    name: 'Blue Dart',
    vehicles: 15,
    activeRoutes: 6,
    utilizationRate: 68,
    status: 'maintenance'
  }
];

const stationData = [
  {
    id: 1,
    name: 'Highway Charging Hub',
    location: 'NH4, Khopoli',
    slots: 8,
    available: 3,
    utilization: 62.5,
    status: 'operational'
  },
  {
    id: 2,
    name: 'ChargePoint Plaza',
    location: 'Mumbai Central',
    slots: 12,
    available: 7,
    utilization: 41.7,
    status: 'operational'
  },
  {
    id: 3,
    name: 'EV Station Alpha',
    location: 'Pune IT Park',
    slots: 6,
    available: 0,
    utilization: 100,
    status: 'maintenance'
  },
  {
    id: 4,
    name: 'Green Energy Hub',
    location: 'Bangalore Tech City',
    slots: 10,
    available: 4,
    utilization: 60,
    status: 'operational'
  }
];

export default function AdminPanel() {
  const [currentUser] = useState(() => {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
  });

  const getCompanyStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <StatusBadge status="success" text="Active" />;
      case 'maintenance':
        return <StatusBadge status="warning" text="Maintenance" />;
      case 'inactive':
        return <StatusBadge status="error" text="Inactive" />;
      default:
        return <StatusBadge status="info" text="Unknown" />;
    }
  };

  const getStationStatusBadge = (status: string) => {
    switch (status) {
      case 'operational':
        return <StatusBadge status="success" text="Operational" />;
      case 'maintenance':
        return <StatusBadge status="warning" text="Maintenance" />;
      case 'offline':
        return <StatusBadge status="error" text="Offline" />;
      default:
        return <StatusBadge status="info" text="Unknown" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={currentUser} title="Admin Panel" />
      
      <div className="container-padding py-6">
        <PageHeader 
          title="System Overview"
          description="Monitor and manage the entire EV fleet charging network"
          actions={
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Station
              </Button>
            </div>
          }
        />

        {/* Admin Stats */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8"
        >
          {adminStats.map((stat, index) => (
            <StatsCard key={stat.title} {...stat} />
          ))}
        </motion.div>

        {/* Main Content Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="companies" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="companies">Companies</TabsTrigger>
              <TabsTrigger value="stations">Charging Stations</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
              <TabsTrigger value="system">System Health</TabsTrigger>
            </TabsList>

            {/* Companies Tab */}
            <TabsContent value="companies" className="space-y-6">
              <Card className="ev-card p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold">Company Management</h3>
                    <p className="text-sm text-muted-foreground">
                      Monitor fleet performance across all companies
                    </p>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Company
                  </Button>
                </div>

                <div className="rounded-xl border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="table-sticky-header">
                        <TableHead>Company</TableHead>
                        <TableHead>Vehicles</TableHead>
                        <TableHead>Active Routes</TableHead>
                        <TableHead>Utilization</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {companyData.map((company) => (
                        <TableRow key={company.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium">{company.name}</TableCell>
                          <TableCell>{company.vehicles}</TableCell>
                          <TableCell>{company.activeRoutes}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress value={company.utilizationRate} className="w-16 h-2" />
                              <span className="text-sm font-medium">{company.utilizationRate}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {getCompanyStatusBadge(company.status)}
                          </TableCell>
                          <TableCell>
                            <Button variant="ghost" size="sm">
                              <Settings className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Card>
            </TabsContent>

            {/* Charging Stations Tab */}
            <TabsContent value="stations" className="space-y-6">
              <Card className="ev-card p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold">Charging Station Network</h3>
                    <p className="text-sm text-muted-foreground">
                      Manage charging infrastructure and monitor utilization
                    </p>
                  </div>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Station
                  </Button>
                </div>

                <div className="rounded-xl border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="table-sticky-header">
                        <TableHead>Station Name</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Slots</TableHead>
                        <TableHead>Available</TableHead>
                        <TableHead>Utilization</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {stationData.map((station) => (
                        <TableRow key={station.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium">{station.name}</TableCell>
                          <TableCell className="text-sm">{station.location}</TableCell>
                          <TableCell>{station.slots}</TableCell>
                          <TableCell>
                            <span className={station.available === 0 ? 'text-destructive font-medium' : 'text-success font-medium'}>
                              {station.available}
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress 
                                value={station.utilization} 
                                className="w-16 h-2" 
                              />
                              <span className="text-sm font-medium">{station.utilization}%</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            {getStationStatusBadge(station.status)}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="sm">
                                <MapPin className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Settings className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Card>
            </TabsContent>

            {/* Analytics Tab */}
            <TabsContent value="analytics">
              <Card className="ev-card p-8 text-center">
                <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Analytics Dashboard</h3>
                <p className="text-muted-foreground">Advanced analytics and reporting features coming soon</p>
              </Card>
            </TabsContent>

            {/* System Health Tab */}
            <TabsContent value="system">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="ev-card p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-success/10">
                      <TrendingUp className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <h3 className="font-semibold">System Performance</h3>
                      <p className="text-sm text-muted-foreground">All systems operational</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">API Response Time</span>
                      <span className="text-sm font-medium text-success">125ms</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Database Performance</span>
                      <span className="text-sm font-medium text-success">Excellent</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Uptime</span>
                      <span className="text-sm font-medium text-success">99.9%</span>
                    </div>
                  </div>
                </Card>

                <Card className="ev-card p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="p-2 rounded-lg bg-info/10">
                      <Calendar className="h-5 w-5 text-info" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Recent Activity</h3>
                      <p className="text-sm text-muted-foreground">Last 24 hours</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="text-sm">
                      <span className="font-medium">128</span> charging sessions completed
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">3</span> new companies registered
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">15</span> routes optimized
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">2</span> stations maintenance completed
                    </div>
                  </div>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}