import { useState } from 'react';
import { motion } from 'framer-motion';
import { Navbar } from '@/components/layout/Navbar';
import { PageHeader } from '@/components/layout/PageHeader';
import { StatsCard } from '@/components/ui/stats-card';
import { StatusBadge } from '@/components/ui/status-badge';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Truck, 
  Users, 
  Zap, 
  MapPin,
  Calendar,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';

// Mock data
const stats = [
  { title: "Active Vehicles", value: 24, icon: Truck, trend: { value: 12, isPositive: true } },
  { title: "Available Drivers", value: 18, icon: Users, trend: { value: 5, isPositive: true } },
  { title: "Charging Sessions", value: 8, icon: Zap, trend: { value: 3, isPositive: false } },
  { title: "Active Routes", value: 12, icon: MapPin, trend: { value: 8, isPositive: true } },
];

const scheduleData = [
  {
    id: 1,
    day: 'Monday',
    driver: 'Rajesh Kumar',
    route: 'Mumbai → Pune',
    time: '06:00 - 14:00',
    chargingNeeded: 'Yes',
    station: 'ChargePoint Hub',
    slot: '12:30 - 13:30',
    status: 'scheduled',
    vehicleId: 'MH-01-AB-1234'
  },
  {
    id: 2,
    day: 'Monday',
    driver: 'Priya Singh',
    route: 'Delhi → Gurgaon',
    time: '08:00 - 16:00',
    chargingNeeded: 'No',
    station: '-',
    slot: '-',
    status: 'sufficient',
    vehicleId: 'DL-02-CD-5678'
  },
  {
    id: 3,
    day: 'Tuesday',
    driver: 'Amit Patel',
    route: 'Bangalore → Chennai',
    time: '05:00 - 18:00',
    chargingNeeded: 'Yes',
    station: 'Pending',
    slot: 'Pending',
    status: 'critical',
    vehicleId: 'KA-03-EF-9012'
  }
];

export default function CompanyPortal() {
  const [currentUser] = useState(() => {
    const user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
  });

  const [selectedWeek, setSelectedWeek] = useState('current');
  const [selectedDriver, setSelectedDriver] = useState('all');

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <StatusBadge status="success" text="Scheduled" />;
      case 'sufficient':
        return <StatusBadge status="info" text="Range OK" />;
      case 'critical':
        return <StatusBadge status="error" text="Critical" />;
      default:
        return <StatusBadge status="warning" text="Pending" />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar user={currentUser} />
      
      <div className="container-padding py-6">
        <PageHeader 
          title="Fleet Dashboard"
          description="Monitor and manage your electric vehicle fleet"
          actions={
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          }
        />

        {/* Stats Overview */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8"
        >
          {stats.map((stat, index) => (
            <StatsCard key={stat.title} {...stat} />
          ))}
        </motion.div>

        {/* Main Content Tabs */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="schedule" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="schedule">Weekly Schedule</TabsTrigger>
              <TabsTrigger value="fleet">Fleet Status</TabsTrigger>
              <TabsTrigger value="drivers">Drivers</TabsTrigger>
              <TabsTrigger value="stations">Charging Stations</TabsTrigger>
            </TabsList>

            {/* Weekly Schedule Tab */}
            <TabsContent value="schedule" className="space-y-6">
              <Card className="ev-card p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
                  <div>
                    <h3 className="text-lg font-semibold">Weekly Schedule</h3>
                    <p className="text-sm text-muted-foreground">
                      Optimize charging and route assignments
                    </p>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                      <SelectTrigger className="w-32">
                        <Calendar className="h-4 w-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="current">This Week</SelectItem>
                        <SelectItem value="next">Next Week</SelectItem>
                        <SelectItem value="prev">Last Week</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                      <SelectTrigger className="w-36">
                        <Filter className="h-4 w-4 mr-2" />
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Drivers</SelectItem>
                        <SelectItem value="rajesh">Rajesh Kumar</SelectItem>
                        <SelectItem value="priya">Priya Singh</SelectItem>
                        <SelectItem value="amit">Amit Patel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="rounded-xl border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="table-sticky-header">
                        <TableHead>Day</TableHead>
                        <TableHead>Driver</TableHead>
                        <TableHead>Route</TableHead>
                        <TableHead>Time</TableHead>
                        <TableHead>Vehicle</TableHead>
                        <TableHead>Charging</TableHead>
                        <TableHead>Station</TableHead>
                        <TableHead>Slot</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {scheduleData.map((item) => (
                        <TableRow key={item.id} className="hover:bg-muted/50">
                          <TableCell className="font-medium">{item.day}</TableCell>
                          <TableCell>{item.driver}</TableCell>
                          <TableCell className="font-mono text-sm">{item.route}</TableCell>
                          <TableCell className="text-sm">{item.time}</TableCell>
                          <TableCell className="font-mono text-xs">{item.vehicleId}</TableCell>
                          <TableCell>
                            <span className={item.chargingNeeded === 'Yes' ? 'text-warning font-medium' : 'text-muted-foreground'}>
                              {item.chargingNeeded}
                            </span>
                          </TableCell>
                          <TableCell>
                            {item.station === 'Pending' ? (
                              <span className="text-destructive">Pending</span>
                            ) : item.station === '-' ? (
                              <span className="text-muted-foreground">-</span>
                            ) : (
                              <span className="text-sm">{item.station}</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {item.slot === 'Pending' ? (
                              <span className="text-destructive">Pending</span>
                            ) : item.slot === '-' ? (
                              <span className="text-muted-foreground">-</span>
                            ) : (
                              <span className="text-sm font-mono">{item.slot}</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(item.status)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </Card>
            </TabsContent>

            {/* Placeholder tabs */}
            <TabsContent value="fleet">
              <Card className="ev-card p-8 text-center">
                <Truck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Fleet Status</h3>
                <p className="text-muted-foreground">Fleet management features coming soon</p>
              </Card>
            </TabsContent>

            <TabsContent value="drivers">
              <Card className="ev-card p-8 text-center">
                <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Driver Management</h3>
                <p className="text-muted-foreground">Driver portal features coming soon</p>
              </Card>
            </TabsContent>

            <TabsContent value="stations">
              <Card className="ev-card p-8 text-center">
                <Zap className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Charging Stations</h3>
                <p className="text-muted-foreground">Station management features coming soon</p>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  );
}